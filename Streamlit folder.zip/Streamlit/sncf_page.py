import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objs as go
import plotly.express as px
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error
from lightgbm import LGBMRegressor
from skforecast.ForecasterAutoreg import ForecasterAutoreg
from skforecast.model_selection import backtesting_forecaster, bayesian_search_forecaster
from skforecast.ForecasterAutoregMultiSeries import ForecasterAutoregMultiSeries
from skforecast.model_selection_multiseries import backtesting_forecaster_multiseries, grid_search_forecaster_multiseries, bayesian_search_forecaster_multiseries
from meteostat import Point, Daily
from datetime import datetime
from sklearn.model_selection import ParameterGrid
import pickle

from sklearn.impute import KNNImputer
from sklearn.experimental import enable_iterative_imputer  # Required for the IterativeImputer
from sklearn.impute import IterativeImputer
from sklearn.ensemble import IsolationForest
import tensorflow as tf


#Load data
data = pd.read_csv("X_train.csv")
target = pd.read_csv("y_train.csv")

# Rename existing exogenous features relating to significance of days (e.g. holiday), and create new features (e.g. weekday, day, month, year)
data['date'] = pd.to_datetime(data['date'])
data = data.rename(columns={'ferie': 'holiday','vacances': 'school_holiday','job':'work_day'})
#data['year'] = data['date'].dt.year
#data['month'] = data['date'].dt.month
#data['day'] = data['date'].dt.day
#data['weekday'] = data['date'].dt.dayofweek

# Separate the station code from the date
target['station'] = target['index'].str[-3:]
target['date'] = target['index'].str[:-4]
target['date'] = pd.to_datetime(target['date'])
target.set_index('date', inplace=True)
target = target.drop(columns=['index'])

# Merge df
merged_df = pd.merge(data, target, on=['date', 'station'], how='left')

# pivot df
df_pivoted = target[['station', 'y']].pivot(columns='station', values='y')

# Find stations to model individually and minimal date for outlier stations
min_date = df_pivoted.apply(lambda col: col.first_valid_index())
min_date = pd.DataFrame(min_date)
min_date = min_date.rename({0 : 'Opening date'}, axis = 1)
min_date_selection = min_date[min_date['Opening date'] > '2015-01-31']
min_date_all = pd.concat([min_date_selection, min_date[min_date.index == 'TV1']], ignore_index=False)
stations_to_model_individually = list(min_date_all.index)

# Detect outliers
def detect_small_outliers_rolling(series, window_size=10, threshold=0.85):
    """
    Detect outliers using a rolling median and deviation method.

    Parameters:
    series (pd.Series): Time series data.
    window_size (int): Size of the rolling window.
    threshold (float): The number of deviations away from the rolling median to consider as outliers.

    Returns:
    pd.Series: Boolean mask indicating outliers.
    """
    rolling_median = series.rolling(window=window_size, center=False).median()
    lower_bound = rolling_median - threshold * rolling_median
    outlier_mask = series < lower_bound

    return outlier_mask

# Clean outliers
def clean_outliers(final_target, window_size, threshold):
    outlier_mask = final_target.apply(detect_small_outliers_rolling, window_size=window_size, threshold=threshold)
    final_target[outlier_mask] = np.nan
    #final_target = final_target.replace(0, np.nan)
    #final_target.interpolate(method='pchip', inplace=True)
    final_target.fillna(0, inplace=True)
    #assert final_target.isna().sum().sum() == 0, "NaN values found after interpolation"

    return final_target


window_size, threshold = 21, 0.8
# Preprocess the data
cleaned_data = clean_outliers(df_pivoted.copy(), window_size, threshold)

# Remove the 9 stations to perfrom individually
cleaned_data = cleaned_data.drop(columns = stations_to_model_individually)



# ============================================ SIDEBAR ============================================ 
st.sidebar.image(r"/Users/admin/Documents/Formation ML Engineer/Projet SNCF/Streamlit/train_series.png", use_column_width=True)
st.sidebar.title("Table of contents")
pages=["Home", "About the project", "Dataset", "Preprocessing", "Evaluation metrics", "Modelisation", "Results and model comparison", "Conclusion"]
page=st.sidebar.radio("Go to", pages)


# ============================================ PAGE 0 ============================================ 
if page == pages[0] : 
  st.markdown("""
    <div style='text-align: center; padding-top: 10vh;'>
        <h1 style='font-size: 60px;'>Anticipate the crowd at SNCF train station of Ile de France</h1>
    </div>
    """, unsafe_allow_html=True)
  st.markdown('--------------------------------------------------------------------------')
  st.markdown("<h2 style='text-align: center;'>Sean Schwager</h2>", unsafe_allow_html=True)
  st.markdown("<h2 style='text-align: center;'>Kamesh Venkata</h2>", unsafe_allow_html=True)
  st.markdown("<h2 style='text-align: center;'>Constance Fromonot</h2>", unsafe_allow_html=True)


# ============================================ PAGE 1 ============================================ 
if page == pages[1] :
  st.markdown("<h1 style='text-align: center; color: #1d8479;'>Context & Presentation of the project</h1>", unsafe_allow_html=True)
  st.image(r"/Users/admin/Documents/Formation ML Engineer/Projet SNCF/Streamlit/carteidf.png", use_column_width=True)

  col1, col2, col3 = st.columns(3)
  with col1:
      st.markdown("<h1 style='text-align: center;'>6 200</h1>", unsafe_allow_html=True)
      st.markdown("<h4 style='text-align: center;'>trains</h4>", unsafe_allow_html=True)
  with col2:
      st.markdown("<h1 style='text-align: center;'>2.3 million</h1>", unsafe_allow_html=True)
      st.markdown("<h4 style='text-align: center;'>validations per day</h4>", unsafe_allow_html=True)
  with col3:
      st.markdown("<h1 style='text-align: center;'>365/365</h1>", unsafe_allow_html=True)
      st.markdown("<h4 style='text-align: center;'>days</h4>", unsafe_allow_html=True)

  col1, col2 = st.columns([0.5, 8.5])
  with col1:
    st.header("🗻")
  with col2: 
    st.write("""##### **Challenges:** Increasing number of passengers are frequent and it impacts the current capabilities of the \
             infrastructure. Better anticipating this increase will help SNCF offer more appropriate services and improve the \
             performance of the operations.""")
    
  col1, col2 = st.columns([0.5, 8.5])
  with col1:
    st.header("🎯")
  with col2: 
     st.write("""##### **Objectives:** Predict the number of validations per day and per station, for the coming year.""")   

  st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>Technical translation</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)
  st.write("""Our problem is **time series prediction**, which falls under **supervised forecasting**. Forecasting involves predicting 
           future values based on previously observed data, and it is widely used to anticipate trends, behaviors, or outcomes 
           in various domains.""")


# ============================================ PAGE 2 ============================================ 
if page == pages[2]: 
    # Header and dataset presentation
    st.markdown("<h1 style='text-align: center; color: #1d8479;'>Presentation of the dataset</h1>", unsafe_allow_html=True)
    st.write("""We have used the data given by the SNCF for a data challenge. They can be found <a href="https://challengedata.ens.fr/challenges/149" target="_blank">here</a>.""", unsafe_allow_html=True)
    st.write("""The dataset looks like this:""")
    st.dataframe(merged_df.head(7))

    # Dataset characteristics
    st.write("""##### Caracteristics of the dataset""")
    st.write(f"""
        - {merged_df.shape[0]} rows and {merged_df.shape[1]} columns.
        - Series length: from 1st January 2015 and 31st December 2022 (2922 days).
        - No null values in the dataset.
        """)

    # Some visualizations
    st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>Some visualizations</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)

    # Plot 1: Total time series with caching
    @st.cache_resource
    def plot_total_affluence():
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=target.index, y=target['y'], mode='lines', 
                                line=dict(color='#649b92', width=1),
                                name='Total Affluence'))
        fig.update_layout(
            title='Evolution of the Total Affluence by Day',
            title_x=0.3,
            xaxis_title='Date',
            yaxis_title='Total Affluence (in thousands of validations)',
            template='plotly_dark',
            yaxis=dict(showgrid=True),
            font=dict(family="Arial, sans-serif", size=14),
            hovermode="x unified",
            width=1000,
            height=500
        )
        return fig
    
    # Show Plot 1 via cache
    st.plotly_chart(plot_total_affluence(), use_container_width=True)

    # Plot 2: Seasonality with caching
    @st.cache_data
    def process_affluence_years():
        df_plot = target.copy()
        df_plot['year'] = target.index.year
        df_plot['month'] = target.index.month
        df_plot = df_plot.groupby(['year', 'month']).agg({'y': ['sum']})
        df_plot.columns = df_plot.columns.get_level_values(0)
        df_plot = df_plot.reset_index()
        return df_plot, df_plot['year'].unique()

    df_plot, affluence_years = process_affluence_years()

    @st.cache_resource
    def plot_seasonality():
        fig = go.Figure()
        mycolors = ['#c1564c', '#00b5cf', '#007664', '#c3fcf2', 'purple', '#ffbf70', '#fd8b7d', '#a26952']

        # Loop through each year and add a trace for each
        for i, year in enumerate(affluence_years):
            to_plot = df_plot.loc[df_plot['year'] == year]
            fig.add_trace(go.Scatter(
                x=to_plot['month'], 
                y=to_plot['y'], 
                mode='lines',
                line=dict(color=mycolors[i], width=2),
                name=str(year)
            ))
        fig.update_layout(
            title='Seasonal Evolution of the Total Affluence by Month',
            title_x=0.3,
            xaxis_title='Months',
            yaxis_title='Total Affluence (in million of validations)',
            template='plotly_dark', 
            yaxis=dict(showgrid=True),
            font=dict(family="Arial, sans-serif", size=14),
            hovermode="x unified",
            legend=dict(title="Year", orientation="v", yanchor="bottom", y=0, xanchor="left", x=0),
            width=1000,
            height=600
        )
        return fig
    
    # Show Plot 2 via cache
    st.plotly_chart(plot_seasonality(), use_container_width=True)

    # Technical considerations
    st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>Technical considerations</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)
    st.write(f"""
        - Variable "y" is the Number of Validation per day and per station: it is our target variable.
        - We consider train set = 2015 to 2021. Test set = 2022.
        """)

    @st.cache_resource
    def load_image():
        return st.image(r"/Users/admin/Documents/Formation ML Engineer/Projet SNCF/Streamlit/frise2.jpg", width=600)
    
    st.markdown("<div style='text-align: center;'>", unsafe_allow_html=True)
    load_image()
    st.markdown("</div>", unsafe_allow_html=True)



# ============================================ PAGE 3 ============================================ 
if page == pages[3] : 
  st.markdown("<h1 style='text-align: center; color: #1d8479;'>Pre processing</h1>", unsafe_allow_html=True)

  # Pivoting the table
  st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>Pivoting the table</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)
  st.write("""The original dataset has 1 row per day per station, but the data needs to be structured such that the time series 
           appear in columns side-by-side (rather than on top of one another). Now, our dataset looks like that:""")
  st.dataframe(df_pivoted)

  # Missing values and outliers handling
  st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>Missing values and outliers handling</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)
  # Missing values
  st.markdown("""
      <div style='text-align: left;'>
          <h5 style='display: inline; color: #1d8479;'>&#8226; Missing values</h5>  <!-- Unicode bullet -->
      </div> """, unsafe_allow_html=True)
  st.write("As mentionned previously, the original dataset had no appearent missing values:")
  null_data = pd.DataFrame(target.isna().sum())
  null_data = null_data.rename({0: 'Number of nan values'}, axis = 1)
  st.dataframe(null_data)
  st.write("But when pivoting the table, it makes apparent the incomplete data within the time series: not every station has \
           a value for every day. In fact, **52 895 values** are missing.") 
  null_data_real = pd.DataFrame(df_pivoted.isna().sum())
  null_data_real = null_data_real.rename({0: 'Real number of nan values'}, axis = 1)
  st.dataframe(null_data_real)
  st.write("""We called these nan values the “maintenance/service days” (when the station shows no valid data for that day,
          presumably related to a station shutdown as a result of some technical fault or planned maintenance).""")
  # Outliers
  st.markdown("""
      <div style='text-align: left;'>
          <h5 style='display: inline; color: #1d8479;'>&#8226; Outliers </h5>  <!-- Unicode bullet -->
      </div> """, unsafe_allow_html=True)
  st.write("""It is insufficient to flag the outliers based purely on identifying the nan values. We should also consider 
           the stations with zero values, or values that have extreme drop (e.g. a station going from 20’000 to 5).""")
  st.write("""To identify them, we use a rolling median method by defining a threshold and window size variable. 
           This method is designed to flag these sudden drops, and output a mask identifying them. This mask is then used to set 
           all maintenance day values to nan, in order to allow imputation methods. Later the threshold and window size can 
           be optimized as new hyperparameters.""")
  
  # Imputation
  st.markdown("""
      <div style='text-align: left;'>
          <h5 style='display: inline; color: #1d8479;'>&#8226; Imputations </h5>  <!-- Unicode bullet -->
      </div> """, unsafe_allow_html=True)
  st.write("""Once these days are identified, we will impute values in place to help the model train. The approach is different for the test and training sets.""")
  st.write("""
           - Training set: imputing 0 on those values (tested against other methods such as linear, quadratic, spline and akima,  Piecewise Cubic Hermite Interpolating Polynomial - PCHIP).
           - Test set: These unpredictable days will certainly have an impact the overall MAPE (discussed further in the modeling chapter). 
           So these values do not need to be imputed.""")
  
  # Result of imputation 
  # Example : station VS0 in october 2022
  st.markdown("""
      <div style='text-align: left;'>
          <h5 style='display: inline; color: #1d8479;'>&#8226; Comparison before and after imputation </h5>  <!-- Unicode bullet -->
      </div> """, unsafe_allow_html=True)

  # Create a dropdown for selecting the station
  selected_station = st.selectbox('Select a station:', df_pivoted.columns)

  # Extract data for the selected station from both dataframes
  df_pivoted_values = df_pivoted[selected_station]
  cleaned_data_values = cleaned_data[selected_station]  # Corresponding column from cleaned_data

  # Create the Plotly figure
  fig = go.Figure()
  fig.add_trace(go.Scatter(x=df_pivoted.index, y=df_pivoted_values, mode='lines', 
                         name='Before imputation: ' + selected_station, 
                         line=dict(color='royalblue', width=2)))
  fig.add_trace(go.Scatter(x=cleaned_data.index, y=cleaned_data_values, mode='lines', 
                         name='After imputation: ' + selected_station, 
                         line=dict(color='firebrick', width=2, dash='dash')))
  fig.update_layout(
    title=f'Comparison of {selected_station} before and after imputation',
    xaxis_title='Date',
    yaxis_title='Values',
    template='plotly_white',
    width=800,
    height=500,
    font=dict(family="Arial, sans-serif", size=14),
    hovermode="x unified",
    legend=dict(title="Data Sources", orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    margin=dict(l=50, r=50, t=50, b=50)
  )
  st.plotly_chart(fig, use_container_width=True)

  # Isolating some stations
  st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>Isolating some stations</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)
  st.write("Some stations opened later than most of the other stations:")
  st.dataframe(min_date_all)
  st.write("""If we consider 2022 as our test set, some stations don't even have training data. 
           As a result, we cannot treat them like the other stations:""")
  st.write("""
           - The stations starting in 2022 are excluded from the analysis because they can not be predicted since we can not train data on an entire year.
           - The station TV1 is open since 01/01/2015, but has very little valid data present in 2022 (more than half of the year) so most of them are imputed. 
           Thus, since this station can not be evaluated correcly, it will also be excluded.
           - The stations starting between 2015-02-01 and 2021-12-31 will be handled independently (with their proper train and test set).""")
  

# ============================================ PAGE 4 ============================================ 
if page == pages[4] : 
    st.markdown("<h1 style='text-align: center; color: #1d8479;'>Evaluation metrics</h1>", unsafe_allow_html=True)

    # MAPE
    st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>MAPE</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)
    st.write("""To evaluate our model, we will use the Mean Absolute Percentage Error on year 2022:""")
    col1, col2, col3 = st.columns([0.5, 2, 0.5])
    with col2:
        st.image(r"/Users/admin/Documents/Formation ML Engineer/Projet SNCF/Streamlit/mape.png", width=300)
    st.write("""It shows, on average, **how much of the prediction is off** from the real value for **each station**, at **each day**.""")
    
    # Mask
    st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>Applying a mask</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)
    st.write("""If a station has a maintenance day within the test set then it wouldn’t matter how accurate the prediction was, this will always lead to an 
             extremely high MAPE that throws off the overall MAPE, thus clouding our ability to accurately interpret the performance of the models.""")
    st.write("<h4 style='text-align: center;'>We cannot evaluate data that is unreliable.</h4>", unsafe_allow_html=True)
    st.write("""So we apply the mask which determined missing value and outliers to the model performance evaluation. So the MAPE will be calculated only on 
             values that are not part of the mask, i.e. valid values that are actually predictable.""")
    col1, col2, col3 = st.columns([0.5, 1.5, 1])
    with col2:
        st.image(r"/Users/admin/Documents/Formation ML Engineer/Projet SNCF/Streamlit/mask2.png", width=600)


# ============================================ PAGE 5 ============================================

if page == pages[5]:
    st.markdown("<h1 style='text-align: center; color: #1d8479;'>Modelisation</h1>", unsafe_allow_html=True)
    st.markdown("""
      <div style='text-align: left;'>
          <h3 style='display: inline; color: #1d8479;'>Objective</h3>
          <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
      </div> """, unsafe_allow_html=True)
    st.write("""
         The aim of the model is to predict daily station validations based on historical data and select exogenous features, accounting for anomalies
         such as maintenance days and station closures, while also conssidering the high multiplicity of stations
         """)
    st.markdown("""
      <div style='text-align: left;'>
          <h3 style='display: inline; color: #1d8479;'>Core framework - SKforecast</h3>
          <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
      </div> """, unsafe_allow_html=True)
    st.write("""
         - Python library built using the widely used scikit-learn API, which provides a comprehensive set of
         tools for training, validation and prediction in a variety of scenarios commonly encountered when working with time series
         """)
    st.write("""
         - For our chosen regressor, we have chosen LightGBM due to its inherant efficiency with large datasets.
         """)

    st.markdown("""
      <div style='text-align: left;'>
          <h3 style='display: inline; color: #1d8479;'>Baseline</h3>
          <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
      </div> """, unsafe_allow_html=True)
    st.write("""
         - Uses the mean of the past 2 years equivalent dates.
         """)
    st.write("""
         - Uses the same outlier cleaning and flagging (to ensure consistency in model evaluation.
         """)

    st.markdown("""
      <div style='text-align: left;'>
          <h3 style='display: inline; color: #1d8479;'>Challenges</h3>
          <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
      </div> """, unsafe_allow_html=True)
    st.write("""
         1. Handling missing data and anomalies (station closures and maintainence).
         """)
    st.write("""
         2. How to best make use of historical data in making those predictions.
         """)
    st.write("""
         3. Optimizing efficiency and accuracy regarding the high multiplicity of time series.
         """)

    st.markdown("""
      <div style='text-align: left;'>
          <h3 style='display: inline; color: #1d8479;'>Challenge 1: Missing Data/Anomalies</h3>
          <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
      </div> """, unsafe_allow_html=True)
    st.write("""
         - Effect of anomalies on training: We use historical data on validations to predict future validations: here they present gaps in the data, negative effect on training.
         """)
    st.write("""
         - Solution: anomaly detection, imputation, and weighting.
         """)
    st.write("""
         - Effects of anomalies on testing (model evaluation): Different problem - using historical data on validations to predict mechanical or technical faults (more advanced - separate model). Exclude from evaluation.
         """)
    st.write("""
         - Solution: using anomaly detection to exclude predictions for anomaly days from model evaluation
         """)

    st.markdown("""
      <div style='text-align: left;'>
          <h3 style='display: inline; color: #1d8479;'>Optimal values for Custom Hyperparameters</h3>
          <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
      </div> """, unsafe_allow_html=True)
    st.write("""
           - Optimal window for anomaly detection: 21 days""")
    st.write("""
           - Optimal threshold for anomaly detection: 0.8""")
    st.write("""
           - Optimal weight for anomalies: 0.1""")
    st.write("""
           - Optimal weight for Covid: 0.8""")
    st.write("""
           - Optimal weight for Summer Maintainence: 0.3""")
    st.write("""
           - Optimal Type of Interpolation: Piecewise Cubic Hermite Interpolating Polynomial (PCHIP)""")


    st.markdown("""
      <div style='text-align: left;'>
          <h3 style='display: inline; color: #1d8479;'>Challenge 2: Historical Features</h3>
          <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
      </div> """, unsafe_allow_html=True)
    st.write("""
         Starting point: ForecasterAutoreg""")
    st.write("""
         - Uses historical data exclusively in the form lags and autoregressive terms
         """)
    st.write("""
         - Hidden function create_predictors
         """)
    st.write("""
         - Lacks more complex feature engineering
         """)
    st.write("""
         Next step: ForecasterAutoregCustom""")
    st.write("""
         - Allows manual access to the "create_predictors" function
         """)
    st.write("""
         - Hidden function create_predictors
         """)
    st.write("""
         - Can add in enriched features for prediction such as rolling mean, stdev, quartiles, and exponential moving average (EMA), etc.
         """)

    st.markdown("""
      <div style='text-align: left;'>
          <h3 style='display: inline; color: #1d8479;'>Challenge 3: High multiplicity of time series</h3>
          <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
      </div> """, unsafe_allow_html=True)
    st.write("""
         Two broad considerations:""")
    st.write("""
         A. Efficiency and Maintainence: Fewer models = better
         """)
    st.write("""
         - It would be more efficient and easier to maintain a single, global model for all 427 stations, than 427 individual models.
         """)
    st.write("""
         B. Accuracy and Performance: Fewer models = ???
         """)
    st.write("""
         Two competing forces:""")
    st.write("""
         (i) Global model may have benefits over the individual models - common external dynamics.
         """)
    st.write("""
         (ii) Global model may also mask the internal patterns within certain stations
         """)
    st.write("""
         Overall this, which is better for our situation needed to be tested empirically (see results next).
         """)
    
# ============================================ PAGE 6 ============================================

if page == pages[6]:
    st.markdown("<h1 style='text-align: center; color: #1d8479;'>Results and Model Comparison</h1>", unsafe_allow_html=True)

    # Load results from pickle files
    @st.cache_data
    def load_backtesting_results():
        backtest_uni_results = pickle.load(open("backtesting_results_uni.pkl", "rb"))
        backtest_multi_results = pickle.load(open("backtesting_results_multi.pkl", "rb"))
        anomaly_results_df = pickle.load(open("backtesting_results_anomaly.pkl", "rb"))
        baseline_results_df = pickle.load(open("backtesting_results_baseline.pkl", "rb"))
        return backtest_uni_results, backtest_multi_results, anomaly_results_df, baseline_results_df

    # Load backtesting results
    backtest_uni_results, backtest_multi_results, anomaly_results_df, baseline_results_df = load_backtesting_results()

    # Unpack results for both models
    overall_mape_uni, uni_series_mape, results_uni, train_target_uni, test_target_uni = backtest_uni_results
    overall_mape_multi, multi_series_mape, results_multi, train_target_multi, test_target_multi = backtest_multi_results
    overall_mape_base = baseline_results_df['mape'].mean()

    # Select Station
    station_options = ['Overall', 'Anomalies'] + list(test_target_uni.columns)
    selected_station = st.selectbox("Select an Option:", station_options)

    if selected_station == 'Overall':
        # Display overall MAPE comparison
        st.write("### Overall MAPE Comparison")
        st.write(f"**Baseline Overall MAPE:** {overall_mape_base:.4f}%")
        st.write(f"**Univariate Overall MAPE:** {overall_mape_uni:.4f}%")
        st.write(f"**Multivariate Overall MAPE:** {overall_mape_multi:.4f}%")

        improvement_uni_over_base = overall_mape_base - overall_mape_uni
        st.write(f"**Improvement in MAPE (univariate over baseline):** {improvement_uni_over_base:.4f}%")

        improvement_multi_over_uni = overall_mape_uni - overall_mape_multi
        st.write(f"**Improvement in MAPE (multiseries over univariate):** {improvement_multi_over_uni:.4f}%")

        # Combine MAPE results from univariate and multiseries models
        mape_multi = pd.Series(multi_series_mape)
        mape_uni = pd.Series(uni_series_mape)
        mape_multi.name = 'mape_multi'
        final_results = pd.concat((mape_uni, mape_multi), axis=1)

        # Calculate the improvement in MAPE for each station
        final_results['improvement'] = final_results.eval('mape_uni - mape_multi')
        final_results['improvement_(%)'] = 100 * final_results.eval('(mape_uni - mape_multi) / mape_uni')
        final_results = final_results.round(2)

        # Plot improvement in MAPE across stations
        fig = go.Figure()

        fig.add_trace(go.Bar(
            x=final_results.index,
            y=final_results['improvement'],
            marker_color=[('#d65f5f' if x < 0 else '#5fba7d') for x in final_results['improvement']],
            name='Improvement in MAPE'
        ))

        fig.add_trace(go.Scatter(
            x=final_results.index,
            y=final_results['improvement'],
            mode='lines',
            line=dict(color='black', width=1),
            name='Multiseries'
        ))

        fig.update_layout(
            title='Improvement in MAPE for All Stations (multiseries over univariate)',
            xaxis_title='Stations',
            yaxis_title='Improvement in MAPE',
            height=600,  # Adjust height
            width=1400,  # Adjust width
            margin=dict(l=40, r=40, t=80, b=40)  # Increase margins for better spacing
        )

        st.plotly_chart(fig, use_container_width=False)

    elif selected_station == 'Anomalies':
        # Display anomaly stations results
        st.write("### Anomaly Stations")

        # Show the DataFrame with results
        cleaned_anomaly_results = anomaly_results_df.drop(columns=['predictions','test_data'])
        st.write(cleaned_anomaly_results)

        # Plot results for anomaly stations
        st.write("### Anomaly Stations MAPE Comparison")
        fig = go.Figure()

        # Plot MAPE for anomaly stations
        fig.add_trace(go.Bar(
            x=anomaly_results_df.index,
            y=anomaly_results_df['mape'],
            marker=dict(color='#1d8479'),
            name='MAPE'
        ))

        # Update layout
        fig.update_layout(
            title='MAPE for Anomaly Stations',
            xaxis_title='Station',
            yaxis_title='MAPE',
            height=600,
            width=1400,
            margin=dict(l=40, r=40, t=80, b=40)
        )

        st.plotly_chart(fig, use_container_width=False)


        # Select Station
        station_options = ['Select Anomaly Station'] + list(anomaly_results_df.index)
        selected_station = st.selectbox("Select a Station:", station_options)

        if selected_station == 'Select Anomaly Station':
            st.write("Please select an anomaly station to view predictions.")
        else:
            st.write(f"### Predictions vs Actual for {selected_station}")

            # Retrieve the results for the selected station
            station_results = anomaly_results_df.loc[selected_station]

            # Extract actual and predicted values
            actual_values = station_results['test_data']
            predicted_values = station_results['predictions'].flatten()

            # Plot Actual vs Predicted
            fig = go.Figure()

            # Plot actual values
            fig.add_trace(go.Scatter(x=actual_values.index, y=actual_values, mode='lines', line=dict(color='blue'), name='Actual'))

            # Plot predicted values
            fig.add_trace(go.Scatter(x=actual_values.index, y=predicted_values, mode='lines', line=dict(color='green', dash='dash', width=1), opacity=0.6, name='Prediction'))

            # Increase graph size and spacing
            fig.update_layout(
                title=f'{selected_station}: Actual vs Predictions',
                xaxis_title='Date',
                yaxis_title='Value',
                height=600,  # Increase height
                width=1400,  # Increase width
                margin=dict(l=40, r=40, t=80, b=40)  # Increase margins for better spacing
            )
            st.plotly_chart(fig, use_container_width=False)

    else:
        # Display MAPE for the selected station
        st.write(f"### MAPE Comparison for {selected_station}")
        st.write(f"**Baseline MAPE (Station {selected_station}):** {baseline_results_df.loc[selected_station]['mape'].mean():.4f}%")
        st.write(f"**Univariate MAPE (Station {selected_station}):** {uni_series_mape[selected_station]:.4f}%")
        st.write(f"**Multivariate MAPE (Station {selected_station}):** {multi_series_mape[selected_station]:.4f}%")

        improvement_uni_over_base = baseline_results_df.loc[selected_station]['mape'].mean() - uni_series_mape[selected_station]
        st.write(f"**Improvement in MAPE (univariate over baseline):** {improvement_uni_over_base:.4f}%")

        improvement_multi_over_uni = uni_series_mape[selected_station] - multi_series_mape[selected_station]
        st.write(f"**Improvement in MAPE (multiseries over univariate):** {improvement_multi_over_uni:.4f}%")

        # Plot Actual vs Predicted for Univariate and Multivariate models
        st.write(f"### Predictions vs Actual for {selected_station}")

        fig = go.Figure()

        # Plot actual values
        actual_values = test_target_multi[selected_station]
        fig.add_trace(go.Scatter(x=actual_values.index, y=actual_values, mode='lines', line=dict(color='blue'), name='Actual'))

        # Plot univariate model predictions
        predictions_uni = results_uni[selected_station]['predictions'].flatten()
        fig.add_trace(go.Scatter(x=actual_values.index, y=predictions_uni, mode='lines', line=dict(color='green', dash='dash',  width=1), opacity=0.6, name='Univariate Prediction'))

        # Plot multivariate model predictions
        predictions_multi = results_multi[selected_station]['predictions']
        fig.add_trace(go.Scatter(x=actual_values.index, y=predictions_multi, mode='lines', line=dict(color='red', dash='dash', width=1), opacity=0.6, name='Multivariate Prediction'))

        # Increase graph size and spacing
        fig.update_layout(
            title=f'{selected_station}: Actual vs Predictions',
            xaxis_title='Date',
            yaxis_title='Value',
            height=600,  # Increase height
            width=1400,  # Increase width
            margin=dict(l=40, r=40, t=80, b=40)  # Increase margins for better spacing
        )
        st.plotly_chart(fig, use_container_width=False)

# ============================================ PAGE 7 ============================================
if page == pages[7]:
    st.markdown("<h1 style='text-align: center; color: #1d8479;'>Conclusion</h1>", unsafe_allow_html=True)

    # Recap of the process
    st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>Recap of the process</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)

    st.write(""" Until now, we have seen:""")
    st.write("""
             - Preprocessing : privoting the table, imputing values using rolling median, isolating outliers stations
             - Modelisation : modelling most of the stations with multi series skforecast, modelling outliers stations with single series skforecast
             - Evaluation : using MAPE and a mask to precit the values that are actually predictible
             """)
    
    # Results
    st.markdown("""
    <div style='text-align: left;'>
        <h3 style='display: inline; color: #1d8479;'>Results</h3>
        <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
    </div> """, unsafe_allow_html=True)

    @st.cache_data
    def load_backtesting_results():
        backtest_uni_results = pickle.load(open("backtesting_results_uni.pkl", "rb"))
        backtest_multi_results = pickle.load(open("backtesting_results_multi.pkl", "rb"))
        anomaly_results_df = pickle.load(open("backtesting_results_anomaly.pkl", "rb"))
        baseline_results_df = pickle.load(open("backtesting_results_baseline.pkl", "rb"))
        return backtest_uni_results, backtest_multi_results, anomaly_results_df, baseline_results_df

    # Load backtesting results
    backtest_uni_results, backtest_multi_results, anomaly_results_df, baseline_results_df = load_backtesting_results()

    # Unpack results for both models
    overall_mape_uni, uni_series_mape, results_uni, train_target_uni, test_target_uni = backtest_uni_results
    overall_mape_multi, multi_series_mape, results_multi, train_target_multi, test_target_multi = backtest_multi_results
    overall_mape_base = baseline_results_df['mape'].mean()

    # Display overall MAPE comparison
    st.write(f"**Baseline Overall MAPE:** {overall_mape_base:.4f}%")
    st.write(f"**Univariate Overall MAPE:** {overall_mape_uni:.4f}%")
    st.write(f"**Multivariate Overall MAPE:** {overall_mape_multi:.4f}%")

    improvement_uni_over_base = overall_mape_base - overall_mape_uni
    st.write(f"**Improvement in MAPE (univariate over baseline):** {improvement_uni_over_base:.4f}%")

    improvement_multi_over_uni = overall_mape_uni - overall_mape_multi
    st.write(f"**Improvement in MAPE (multiseries over univariate):** {improvement_multi_over_uni:.4f}%")
    
    # Improvment
    st.markdown("""
          <div style='text-align: left;'>
              <h3 style='display: inline; color: #1d8479;'>Future Improvements</h3>
              <hr style='border: 0; height: 1px; background-color: #1d8479; margin-top: 10px; width: 50%;'>
          </div> """, unsafe_allow_html=True)
    st.write("""
             1. Better data regarding planned or scheduled maintainance.""")
    st.write("""
             2. Use of an ensemble model, that incorporates a second model deticated to anomaly detection or technical fault modelling.
             """)
    st.write("""
             3. Use of Support Vector Regression or some other method to be trained on the residuals from Skforecast, and improve the predictions.
             """)
    st.write("""
             4. Further optimization of hyperparemeters.
             """)
    st.write("""
             5. Incorporating the time of day, allowing us to identify when each station is busiest.
             """)
             



